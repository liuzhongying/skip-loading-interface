@echo off
cd /d "%~dp0"
set HOST=0.0.0.0
set PORT=8000
start "" "http://127.0.0.1:8000"
"%~dp0skip-loading-interface.exe"
pause
